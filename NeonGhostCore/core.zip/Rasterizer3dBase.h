#pragma once
#include <cstdint>
#include <cmath>
#include <algorithm>
#include "Frustum.h"
#include "Texture.h"


namespace ng::renderer::rasterizer
{
    // ================================================================
    // Depth compare function pointer
    // Signatur: bool(T newZ, T storedZ)
    // ================================================================
    template<class T>
    using DepthFuncPtr = bool(*)(T newZ, T storedZ);

    template<class T> inline bool DepthFunc_Never(T, T) { return false; }
    template<class T> inline bool DepthFunc_Less(T newZ, T storedZ) { return newZ < storedZ; }
    template<class T> inline bool DepthFunc_Equal(T newZ, T storedZ) { return newZ == storedZ; }
    template<class T> inline bool DepthFunc_LEqual(T newZ, T storedZ) { return newZ <= storedZ; }
    template<class T> inline bool DepthFunc_Greater(T newZ, T storedZ) { return newZ > storedZ; }
    template<class T> inline bool DepthFunc_NotEqual(T newZ, T storedZ) { return newZ != storedZ; }
    template<class T> inline bool DepthFunc_GEqual(T newZ, T storedZ) { return newZ >= storedZ; }
    template<class T> inline bool DepthFunc_Always(T, T) { return true; }

    enum DepthFunc : uint32_t
    {
        DEPTHFUNC_NEVER,
        DEPTHFUNC_LESS,
        DEPTHFUNC_EQUAL,
        DEPTHFUNC_LESSEQUAL,
        DEPTHFUNC_GREATER,
        DEPTHFUNC_NOTEQUAL,
        DEPTHFUNC_GREATEREQUAL,
        DEPTHFUNC_ALWWAYS
    };


    template <class T>
    inline DepthFuncPtr<T> SelectDepthFn_Impl(uint32_t func)
    {
        switch (func)
        {
        case DEPTHFUNC_NEVER:        return DepthFunc_Never<T>;
        case DEPTHFUNC_LESS:         return DepthFunc_Less<T>;
        case DEPTHFUNC_EQUAL:        return DepthFunc_Equal<T>;
        case DEPTHFUNC_LESSEQUAL:    return DepthFunc_LEqual<T>;
        case DEPTHFUNC_GREATER:      return DepthFunc_Greater<T>;
        case DEPTHFUNC_NOTEQUAL:     return DepthFunc_NotEqual<T>;
        case DEPTHFUNC_GREATEREQUAL: return DepthFunc_GEqual<T>;
        case DEPTHFUNC_ALWWAYS:      return DepthFunc_Always<T>;
        }

        return DepthFunc_Less<T>;
    }
}


// ---------------------------------------------------------------------
// Erwartete Umgebung (bei dir bereits vorhanden):
//   - math::matrix<N,1,T> mit .x()/.y()/.z()/.w() Zugriff
//   - primitive::SVertex<T>  (screen-space Vertex nach Project())
//   - RGBA(r,g,b,a) -> uint32_t
//   - RGBToRed/Green/Blue/Alpha
// ---------------------------------------------------------------------

namespace ng::renderer::rasterizer
{
    // -------------------------------------------------------------
    // RenderTarget: buendelt alle Ausgabebuffer, die der Rasterizer
    // beschreibt.
    // -------------------------------------------------------------
    template<class T>
    struct RenderTarget
    {
        uint32_t* color = nullptr; // ARGB8888
        T* depth = nullptr; // 1/w, groesser = naeher an der Kamera
        uint32_t* normal = nullptr; // gepackte Normale (siehe PackNormal)
        uint32_t* index = nullptr; // Objekt-/Primitiv-ID pro Pixel

        int width = 0;
        int height = 0;

        inline size_t Offset(int x, int y) const { return (size_t)y * width + x; }
    };

    // Normale in ein uint32 packen (je Kanal 8 Bit, -1..1 -> 0..255)
    template<class T>
    inline uint32_t PackNormal(T x, T y, T z)
    {
        auto enc = [](T v) -> uint32_t
            {
                v = std::clamp(v, (T)-1, (T)1);
                return (uint32_t)((v * (T)0.5 + (T)0.5) * (T)255);
            };
        return (0xffu << 24) | (enc(x) << 16) | (enc(y) << 8) | enc(z);
    }

    // 256-Eintraege-LUT, einmal anlegen
    inline const float* NormalLut()
    {
        static float lut[256];
        static bool init = false;
        if (!init)
        {
            for (int i = 0; i < 256; ++i) lut[i] = float(i) / 255.0f * 2.0f - 1.0f;
            init = true;
        }
        return lut;
    }

    template <class T>
    inline bool UnpackNormal(uint32_t c, ng::math::Matrix<3, 1, T>& n)
    {
        if ((c >> 24) == 0) return false;          // nie beschrieben (Clear-Wert 0)
        const float* lut = NormalLut();
        n = ng::math::Matrix<3, 1, T>(T(lut[(c >> 16) & 255]),
            T(lut[(c >> 8) & 255]),
            T(lut[c & 255]));
        return true;
    }

    // -------------------------------------------------------------
    // Textur-View: keine eigene Ressourcenverwaltung, nur ein
    // Blick auf existierende Pixeldaten.
    // -------------------------------------------------------------
    struct TextureView
    {
        ng::renderer::gfx::Texture texture;   // Resource-Handle - billig zu kopieren/halten

        // ---------------------------------------------------------
        // Packed-Lerp: interpoliert alle 4 Kanaele gleichzeitig.
        // t = 0..256 (0 -> c0, 256 -> c1)
        // ---------------------------------------------------------
        static inline uint32_t Lerp8(uint32_t c0, uint32_t c1, uint32_t t)
        {
            const uint32_t it = 256u - t;
            const uint32_t rb = (((c0 & 0x00ff00ffu) * it + (c1 & 0x00ff00ffu) * t) >> 8) & 0x00ff00ffu;
            const uint32_t ag = (((c0 >> 8) & 0x00ff00ffu) * it + ((c1 >> 8) & 0x00ff00ffu) * t) & 0xff00ff00u;
            return rb | ag;
        }

        // ---------------------------------------------------------
        // Nearest
        // ---------------------------------------------------------
        template<class T>
        inline uint32_t SampleNearestLevel(T u, T v, int level) const
        {
            if (!texture) return 0xffff00ffu; // Magenta = fehlende Textur
            const auto& mip = texture->GetMipLevel(level);
            int w = mip.Width(), h = mip.Height();
            if (w <= 0 || h <= 0) return 0xffff00ffu;
            int x = (int)(u * (T)w) % w;
            int y = (int)(v * (T)h) % h;
            if (x < 0) x += w;
            if (y < 0) y += h;
            return mip.GetRawBuffer()[(size_t)y * w + x];
        }

        // ---------------------------------------------------------
        // Bilinear auf einem Mip-Level.
        // clampEdge = false -> Repeat (Diffuse)
        // clampEdge = true  -> Clamp  (Lightmaps, kein Bluten ueber den Rand)
        // ---------------------------------------------------------
        template<class T>
        inline uint32_t SampleBilinearLevel(T u, T v, int level, bool clampEdge = false) const
        {
            if (!texture) return 0xffff00ffu;
            const auto& mip = texture->GetMipLevel(level);
            const int w = mip.Width(), h = mip.Height();
            if (w <= 0 || h <= 0) return 0xffff00ffu;
            const uint32_t* px = mip.GetRawBuffer();

            const float fx = float(u) * w - 0.5f;
            const float fy = float(v) * h - 0.5f;
            const float flx = std::floor(fx), fly = std::floor(fy);
            const uint32_t ax = (uint32_t)std::clamp((fx - flx) * 256.0f, 0.0f, 256.0f);
            const uint32_t ay = (uint32_t)std::clamp((fy - fly) * 256.0f, 0.0f, 256.0f);

            int x0, x1, y0, y1;
            if (clampEdge)
            {
                x0 = std::clamp((int)flx, 0, w - 1);
                x1 = std::clamp((int)flx + 1, 0, w - 1);
                y0 = std::clamp((int)fly, 0, h - 1);
                y1 = std::clamp((int)fly + 1, 0, h - 1);
            }
            else
            {
                auto wrap = [](int i, int n) { i %= n; return i < 0 ? i + n : i; };
                x0 = wrap((int)flx, w);     x1 = wrap((int)flx + 1, w);
                y0 = wrap((int)fly, h);     y1 = wrap((int)fly + 1, h);
            }

            const uint32_t top = Lerp8(px[(size_t)y0 * w + x0], px[(size_t)y0 * w + x1], ax);
            const uint32_t bot = Lerp8(px[(size_t)y1 * w + x0], px[(size_t)y1 * w + x1], ax);
            return Lerp8(top, bot, ay);
        }

        // Alte Variante (GetPixel-basiert) - bleibt der Vollstaendigkeit halber
        template<class T>
        inline uint32_t SampleLightmapBilinear(T u, T v) const
        {
            return SampleBilinearLevel(u, v, 0, true);
        }

        // ---------------------------------------------------------
        // Mip-Level aus Bildschirmraum-Ableitungen (diskret)
        // ---------------------------------------------------------
        template<class T>
        inline int SelectMipLevel(T dudx, T dvdx, T dudy, T dvdy) const
        {
            if (!texture) return 0;
            int w = texture->Width(), h = texture->Height();
            T ddx = dudx * (T)w, ddy = dvdx * (T)h;
            T edx = dudy * (T)w, edy = dvdy * (T)h;
            T rho = std::sqrt(std::max(ddx * ddx + ddy * ddy, edx * edx + edy * edy));
            if (rho <= (T)1) return 0;
            int level = (int)std::log2((double)rho);
            // FIX: hoechster gueltiger Index ist Anzahl-1
            return std::clamp(level, 0, (int)texture->GetMipLevels() - 1);
        }

        // ---------------------------------------------------------
        // Kontinuierlicher LOD (fuer Trilinear)
        // ---------------------------------------------------------
        template<class T>
        inline T SelectLod(T dudx, T dvdx, T dudy, T dvdy, T bias = T(0)) const
        {
            if (!texture) return 0;
            const int w = texture->Width(), h = texture->Height();
            T ddx = dudx * (T)w, ddy = dvdx * (T)h;
            T edx = dudy * (T)w, edy = dvdy * (T)h;
            T rho2 = std::max(ddx * ddx + ddy * ddy, edx * edx + edy * edy);
            if (rho2 <= (T)1e-12) return std::clamp(bias, (T)0, (T)(texture->GetMipLevels() - 1));
            T lod = (T)0.5 * (T)std::log2((double)rho2) + bias;   // log2(sqrt(x)) = 0.5*log2(x)
            return std::clamp(lod, (T)0, (T)(texture->GetMipLevels() - 1));
        }

        template<class T>
        inline uint32_t SampleTrilinear(T u, T v, T lod) const
        {
            const int maxL = (int)texture->GetMipLevels() - 1;
            const int l0 = std::min((int)lod, maxL);
            const int l1 = std::min(l0 + 1, maxL);
            const uint32_t t = (uint32_t)((lod - (T)l0) * (T)256);
            const uint32_t a = SampleBilinearLevel(u, v, l0);
            if (l0 == l1 || t == 0) return a;
            return Lerp8(a, SampleBilinearLevel(u, v, l1), t);
        }
    };


    template<class T>
    struct Fragment
    {
        int x, y;

        T invW;

        T u, v;
        T fxu, fxv;

        // Ableitungen der perspektivisch korrigierten UVs
        T dudx, dvdx;
        T dudy, dvdy;

        T r, g, b, a;

        T nx, ny, nz;
    };

    // -------------------------------------------------------------
    // DrawState: alles, was fuer einen kompletten Draw-Call konstant ist.
    // -------------------------------------------------------------
    enum RasterFlags : uint32_t
    {
        RASTER_NONE = 0,
        RASTER_VERTEXCOLOR = 1u << 0,
        RASTER_TEXTURE = 1u << 1,
        RASTER_LIGHTMAP = 1u << 2, // nur zusammen mit RASTER_TEXTURE sinnvoll
        RASTER_TRANSPARENT = 1u << 3,
        RASTER_DEPTH_TEST = 1u << 4,
        RASTER_DEPTH_WRITE = 1u << 5,
        RASTER_WRITE_NORMAL = 1u << 6,
        RASTER_WRITE_INDEX = 1u << 7,
        RASTER_DEPTH_CLEAR = 1u << 8,
        RASTER_WARP = 1u << 9,
        RASTER_WARP_SCREEN = 1u << 10,

        // NEU: Texturfilterung
        RASTER_FILTER_BILINEAR = 1u << 11,   // bilinear innerhalb eines Mip-Levels
        RASTER_FILTER_TRILINEAR = 1u << 12,  // bilinear + Blend zwischen Mip-Levels
        RASTER_LIGHTMAP_BILINEAR = 1u << 13  // Lightmap bilinear filtern
    };

    struct LightmapCorrection
    {
        float gamma = 1.0f;   // 1.0 = aus, 1.6 bis 2.2 = heller
        float brightness = 1.0f;   // linearer Faktor, 1.0 = aus, 2.0 = Overbright

        uint8_t  lut[256];         // Gamma-Tabelle
        uint32_t scale = 0;        // Brightness als Festkomma (siehe Shader)

        LightmapCorrection() { Rebuild(); }

        void Rebuild()
        {
            const float invG = 1.0f / std::max(0.1f, gamma);
            for (int i = 0; i < 256; ++i)
            {
                const float v = std::pow(i / 255.0f, invG);
                lut[i] = (uint8_t)std::clamp(v * 255.0f + 0.5f, 0.0f, 255.0f);
            }
            // br*lr*brightness/255  ==  (br*lr*scale) >> 16
            scale = (uint32_t)(std::clamp(brightness, 0.0f, 16.0f) * 65536.0f / 255.0f + 0.5f);
        }
    };

    template<class T>
    struct DrawState
    {
        // ------------------------------------------------------------
        // Depth
        // ------------------------------------------------------------
        bool      depthTestEnabled = true;
        bool      depthWriteEnabled = true;

        uint32_t flags = RASTER_DEPTH_TEST | RASTER_DEPTH_WRITE;
        uint32_t detph = DEPTHFUNC_LESS;
        uint32_t flatColor = 0xffffffffu; // genutzt wenn weder VERTEXCOLOR noch TEXTURE
        uint32_t objectIndex = 0;
        T materialAlpha = (T)1;            // zusaetzlich zur Vertex-/Textur-Alpha

        const TextureView* diffuseTex = nullptr;
        const TextureView* lightmapTex = nullptr;

        uint32_t(*colorFn)(const Fragment<T>&, const DrawState<T>&) = nullptr;
        void     (*writeFn)(RenderTarget<T>&, size_t offset, uint32_t color, const DrawState<T>&) = nullptr;
        DepthFuncPtr<T> depthFn = nullptr;

        const LightmapCorrection* lmCorrection = nullptr;

        T dU_dx = 0;
        T dU_dy = 0;
        T dV_dx = 0;
        T dV_dy = 0;

        // NEU: LOD-Bias fuer Trilinear. -0.5 = schaerfer, +0.5 = weicher
        T lodBias = T(0);

        T warpAmp = T(0.03);   // Amplitude in UV-Einheiten
        T warpFreq = T(8.0);   // Wellen pro UV-Einheit
        T warpTime = T(0);     // Sekunden

        T warpScreenFreq = T(0.06);
    };

    // ===============================================================
    // ColorFn-Implementierungen
    // ===============================================================
    template<class T>
    inline uint32_t ColorFlat(const Fragment<T>&, const DrawState<T>& st)
    {
        return st.flatColor;
    }

    template<class T>
    inline uint32_t ColorVertex(const Fragment<T>& f, const DrawState<T>&)
    {
        uint8_t r = (uint8_t)std::clamp(f.r * (T)255, (T)0, (T)255);
        uint8_t g = (uint8_t)std::clamp(f.g * (T)255, (T)0, (T)255);
        uint8_t b = (uint8_t)std::clamp(f.b * (T)255, (T)0, (T)255);

        return RGBA(r, g, b, 255);
    }

    // Perspektivisch korrekte Ableitung von u = U / invW (Quotientenregel):
    //   du/dx = (dU * invW - U * dInvW) / invW^2
    // Parameter:
    //   value  = roher, linear interpolierter Wert U (= u/w)
    //   w      = 1 / invW  (Pixel-Loop hat das schon)
    //   dValue = dU/dx bzw. dU/dy
    //   dInvW  = dInvW/dx bzw. dInvW/dy
    template<class T>
    inline T PerspectiveDerivative(T value, T w, T dValue, T dInvW)
    {
        const T invW = (T)1 / w;
        T result = (dValue * invW - value * dInvW) * (w * w);   // FIX: * w^2 statt * invW^2
        return std::isfinite((double)result) ? result : T(0);
    }


    template<class T>
    inline T WarpSin(T x)
    {
        static float table[1024];
        static bool init = false;
        if (!init)
        {
            for (int i = 0; i < 1024; ++i)
                table[i] = std::sin(i * 6.28318530718f / 1024.f);
            init = true;
        }
        const int i = (int)std::floor((double)x * (1024.0 / 6.28318530718));
        return (T)table[i & 1023];
    }


    template<class T>
    inline uint32_t ColorTexture(const Fragment<T>& f, const DrawState<T>& st)
    {
        if (!st.diffuseTex)
            return 0xffff00ffu;

        T u = f.u, v = f.v;
        if (st.flags & RASTER_WARP)
        {
            const T t = st.warpTime * T(2);
            const T ou = u, ov = v;
            u = ou + st.warpAmp * WarpSin<T>(ov * st.warpFreq + t);
            v = ov + st.warpAmp * WarpSin<T>(ou * st.warpFreq + t * T(1.15));
        }

        if (st.flags & RASTER_WARP_SCREEN)
        {
            const T t = st.warpTime * T(2);
            const T ou = u, ov = v;
            u = ou + st.warpAmp * WarpSin<T>((T)f.y * st.warpScreenFreq + t);
            v = ov + st.warpAmp * WarpSin<T>((T)f.x * st.warpScreenFreq + t * T(1.15));
        }

        // NEU: Filterwahl
        uint32_t tex;
        if (st.flags & RASTER_FILTER_TRILINEAR)
        {
            const T lod = st.diffuseTex->SelectLod(f.dudx, f.dvdx, f.dudy, f.dvdy, st.lodBias);
            tex = st.diffuseTex->SampleTrilinear(u, v, lod);
        }
        else if (st.flags & RASTER_FILTER_BILINEAR)
        {
            const int mip = st.diffuseTex->SelectMipLevel(f.dudx, f.dvdx, f.dudy, f.dvdy);
            tex = st.diffuseTex->SampleBilinearLevel(u, v, mip);
        }
        else
        {
            const int mip = st.diffuseTex->SelectMipLevel(f.dudx, f.dvdx, f.dudy, f.dvdy);
            tex = st.diffuseTex->SampleNearestLevel(u, v, mip);
        }

        uint32_t tr = RGBToRed(tex);
        uint32_t tg = RGBToGreen(tex);
        uint32_t tb = RGBToBlue(tex);
        uint32_t ta = RGBToAlpha(tex);

        // Nur modulieren, wenn explizit gewuenscht.
        if (st.flags & RASTER_VERTEXCOLOR)
        {
            uint32_t r = (uint32_t)(((T)tr / (T)255) * f.r * (T)255);
            uint32_t g = (uint32_t)(((T)tg / (T)255) * f.g * (T)255);
            uint32_t b = (uint32_t)(((T)tb / (T)255) * f.b * (T)255);
            return RGBA(r, g, b, ta);
        }

        return RGBA(tr, tg, tb, ta);
    }


    template<class T>
    inline uint32_t ColorTextureLightmap(const Fragment<T>& f, const DrawState<T>& st)
    {
        uint32_t base = ColorTexture(f, st);
        if (!st.lightmapTex || !st.lightmapTex->texture) return base;

        // NEU: Lightmap bilinear (Clamp), sonst Nearest
        uint32_t lm;
        if (st.flags & RASTER_LIGHTMAP_BILINEAR)
            lm = st.lightmapTex->SampleBilinearLevel(f.fxu, f.fxv, 0, true);
        else
            lm = st.lightmapTex->SampleNearestLevel(f.fxu, f.fxv, 0);

        uint32_t lr = (lm >> 16) & 0xff, lg = (lm >> 8) & 0xff, lb = lm & 0xff;
        uint32_t br = (base >> 16) & 0xff, bg = (base >> 8) & 0xff, bb = base & 0xff, ba = (base >> 24) & 0xff;

        uint32_t r, g, b;
        if (st.lmCorrection)
        {
            const auto& c = *st.lmCorrection;
            lr = c.lut[lr]; lg = c.lut[lg]; lb = c.lut[lb];

            r = std::min(255u, (br * lr * c.scale) >> 16);
            g = std::min(255u, (bg * lg * c.scale) >> 16);
            b = std::min(255u, (bb * lb * c.scale) >> 16);
        }
        else
        {
            r = (br * lr) / 255u;
            g = (bg * lg) / 255u;
            b = (bb * lb) / 255u;
        }
        return (ba << 24) | (r << 16) | (g << 8) | b;
    }

    template<class T>
    inline void SelectColorFn_Impl(uint32_t flags, uint32_t(**out)(const Fragment<T>&, const DrawState<T>&))
    {
        if (flags & RASTER_TEXTURE)
        {
            *out = (flags & RASTER_LIGHTMAP) ? ColorTextureLightmap<T> : ColorTexture<T>;
        }
        else if (flags & RASTER_VERTEXCOLOR)
        {
            *out = ColorVertex<T>;
        }
        else
        {
            *out = ColorFlat<T>;
        }
    }

    // ===============================================================
    // WriteFn-Implementierungen
    // ===============================================================
    template<class T>
    inline void WriteOpaque(RenderTarget<T>& target, size_t offset, uint32_t color, const DrawState<T>&)
    {
        target.color[offset] = color;
    }

    template<class T>
    inline void WriteBlend(RenderTarget<T>& target, size_t offset, uint32_t color, const DrawState<T>& st)
    {
        uint32_t srcA = (uint32_t)std::clamp(((color >> 24) & 0xff) * st.materialAlpha, (T)0, (T)255);
        if (srcA == 0) return;
        if (srcA >= 255) { target.color[offset] = color; return; }

        uint32_t dst = target.color[offset];
        uint32_t sr = (color >> 16) & 0xff, sg = (color >> 8) & 0xff, sb = color & 0xff;
        uint32_t dr = (dst >> 16) & 0xff, dg = (dst >> 8) & 0xff, db = dst & 0xff;

        uint32_t r = (sr * srcA + dr * (255 - srcA)) / 255;
        uint32_t g = (sg * srcA + dg * (255 - srcA)) / 255;
        uint32_t b = (sb * srcA + db * (255 - srcA)) / 255;
        target.color[offset] = (0xffu << 24) | (r << 16) | (g << 8) | b;
    }

    template<class T>
    inline void SelectWriteFn_Impl(uint32_t flags, void (**out)(RenderTarget<T>&, size_t, uint32_t, const DrawState<T>&))
    {
        *out = (flags & RASTER_TRANSPARENT) ? WriteBlend<T> : WriteOpaque<T>;
    }

    // Einmal pro Draw-Call aufrufen, bevor gerastert wird.
    template<class T>
    inline void SelectDrawFunctions(ng::renderer::rasterizer::DrawState<T>& st)
    {
        st.depthFn = SelectDepthFn_Impl<T>(st.detph);
        SelectColorFn_Impl<T>(st.flags, &st.colorFn);
        SelectWriteFn_Impl<T>(st.flags, &st.writeFn);
    }

    // -------------------------------------------------------------
    // Ein Pixel durch die komplette Pipeline schicken: Tiefentest,
    // ColorFn, WriteFn, optional Normal-/Index-Buffer.
    // -------------------------------------------------------------
    template<class T>
    inline void ShadePixel(RenderTarget<T>& target, const DrawState<T>& st, const Fragment<T>& f)
    {
        if ((unsigned)f.x >= (unsigned)target.width || (unsigned)f.y >= (unsigned)target.height) return;
        size_t offset = target.Offset(f.x, f.y);

        if (st.flags & RASTER_DEPTH_TEST)
        {
            if (st.depthFn(f.invW, target.depth[offset])) return;
        }

        // Portal-Bereich freigeben - kein Farbwert, nur Tiefe zuruecksetzen
        if (st.flags & RASTER_DEPTH_CLEAR)
        {
            target.depth[offset] = 0.0f;
            return;
        }

        if (st.flags & RASTER_WRITE_NORMAL)
        {
            T l = std::sqrt(f.nx * f.nx + f.ny * f.ny + f.nz * f.nz);
            if (l > T(1e-6)) l = T(1) / l; else l = T(0);
            target.normal[offset] = PackNormal<T>(f.nx * l, f.ny * l, f.nz * l);
        }

        uint32_t color = st.colorFn(f, st);
        st.writeFn(target, offset, color, st);

        if (st.flags & RASTER_DEPTH_WRITE)
            target.depth[offset] = (float)f.invW;
        if (st.flags & RASTER_WRITE_NORMAL)
            target.normal[offset] = PackNormal<T>(f.nx, f.ny, f.nz);
        if (st.flags & RASTER_WRITE_INDEX)
            target.index[offset] = st.objectIndex;
    }

    // ===============================================================
    // Line3D
    // ===============================================================
    template<class T, class SVertexT>
    inline void DrawLine3D(RenderTarget<T>& target, DrawState<T>& st, const SVertexT& v0, const SVertexT& v1)
    {
        SelectDrawFunctions(st);

        T dx = v1.x() - v0.x();
        T dy = v1.y() - v0.y();
        int steps = (int)std::max(std::abs(dx), std::abs(dy));
        if (steps <= 0)
        {
            Fragment<T> f{ (int)v0.x(), (int)v0.y(), v0.w(),
                v0.u(), v0.v(), v0.fxu(), v0.fxv(),
                0, 0, 0, 0,
                v0.color().x(), v0.color().y(), v0.color().z(), v0.alpha(),
                v0.normal().x(), v0.normal().y(), v0.normal().z() };

            ShadePixel(target, st, f);
            return;
        }

        T invSteps = (T)1 / (T)steps;
        for (int i = 0; i <= steps; i++)
        {
            T t = i * invSteps;
            Fragment<T> f{};

            f.x = (int)v0.x();
            f.y = (int)v0.y();

            f.invW = v0.w();

            f.u = v0.u();
            f.v = v0.v();
            f.fxu = v0.fxu();
            f.fxv = v0.fxv();

            // Bei einer Linie verwenden wir kein Mipmapping.
            f.dudx = 0;
            f.dvdx = 0;
            f.dudy = 0;
            f.dvdy = 0;

            f.r = v0.color().x();
            f.g = v0.color().y();
            f.b = v0.color().z();
            f.a = v0.alpha();

            f.nx = v0.normal().x();
            f.ny = v0.normal().y();
            f.nz = v0.normal().z();

            ShadePixel(target, st, f);
        }
    }

    // ===============================================================
    // Fast Triangle (Gradienten-Rasterizer)
    // ===============================================================
    template<class T>
    struct Gradients
    {
        T dInvW_dx, dInvW_dy;
        T dU_dx, dU_dy, dV_dx, dV_dy;
        T dFxu_dx, dFxu_dy, dFxv_dx, dFxv_dy;
        T dR_dx, dR_dy, dG_dx, dG_dy, dB_dx, dB_dy, dA_dx, dA_dy;
        T dNx_dx, dNx_dy, dNy_dx, dNy_dy, dNz_dx, dNz_dy;

        template<class SVertexT>
        Gradients(const SVertexT& v0, const SVertexT& v1, const SVertexT& v2)
        {
            T denom = (v1.x() - v2.x()) * (v0.y() - v2.y()) - (v0.x() - v2.x()) * (v1.y() - v2.y());
            if (std::abs(denom) < (T)1e-8) denom = (T)1e-8; // entartetes Dreieck absichern
            T oneOverDx = (T)1 / denom;
            T oneOverDy = -oneOverDx;

            auto grad = [&](T a0, T a1, T a2, T& outDx, T& outDy)
                {
                    outDx = ((a1 - a2) * (v0.y() - v2.y()) - (a0 - a2) * (v1.y() - v2.y())) * oneOverDx;
                    outDy = ((a1 - a2) * (v0.x() - v2.x()) - (a0 - a2) * (v1.x() - v2.x())) * oneOverDy;
                };

            grad(v0.w(), v1.w(), v2.w(), dInvW_dx, dInvW_dy);
            grad(v0.u(), v1.u(), v2.u(), dU_dx, dU_dy);
            grad(v0.v(), v1.v(), v2.v(), dV_dx, dV_dy);
            grad(v0.fxu(), v1.fxu(), v2.fxu(), dFxu_dx, dFxu_dy);
            grad(v0.fxv(), v1.fxv(), v2.fxv(), dFxv_dx, dFxv_dy);
            grad(v0.color().x(), v1.color().x(), v2.color().x(), dR_dx, dR_dy);
            grad(v0.color().y(), v1.color().y(), v2.color().y(), dG_dx, dG_dy);
            grad(v0.color().z(), v1.color().z(), v2.color().z(), dB_dx, dB_dy);
            grad(v0.alpha(), v1.alpha(), v2.alpha(), dA_dx, dA_dy);
            grad(v0.normal().x(), v1.normal().x(), v2.normal().x(), dNx_dx, dNx_dy);
            grad(v0.normal().y(), v1.normal().y(), v2.normal().y(), dNy_dx, dNy_dy);
            grad(v0.normal().z(), v1.normal().z(), v2.normal().z(), dNz_dx, dNz_dy);
        }
    };


    template<class T>
    struct Edge
    {
        T x, xStep;
        int yStart, yEnd;

        T invW, invW_step;
        T u, u_step, v, v_step;
        T fxu, fxu_step, fxv, fxv_step;
        T r, r_step, g, g_step, b, b_step, a, a_step;
        T nx, nx_step, ny, ny_step, nz, nz_step;

        template<class SVertexT>
        Edge(
            const SVertexT& top,
            const SVertexT& bottom,
            const Gradients<T>& grad)
        {
            yStart = (int)std::ceil(top.y() - (T)0.5);
            yEnd = (int)std::ceil(bottom.y() - (T)0.5);

            T yDist = bottom.y() - top.y();
            T xDist = bottom.x() - top.x();

            if (std::abs(yDist) < (T)1e-6)
                yDist = (T)1e-6;

            xStep = xDist / yDist;

            T yPreStep = (T)yStart + (T)0.5 - top.y();

            x = top.x() + yPreStep * xStep;

            T xPreStep = x - top.x();

            auto init =
                [&](T topVal, T dx, T dy, T& val, T& step)
                {
                    val = topVal + xPreStep * dx + yPreStep * dy;
                    step = xStep * dx + dy;
                };

            init(top.w(), grad.dInvW_dx, grad.dInvW_dy, invW, invW_step);
            init(top.u(), grad.dU_dx, grad.dU_dy, u, u_step);
            init(top.v(), grad.dV_dx, grad.dV_dy, v, v_step);
            init(top.fxu(), grad.dFxu_dx, grad.dFxu_dy, fxu, fxu_step);
            init(top.fxv(), grad.dFxv_dx, grad.dFxv_dy, fxv, fxv_step);
            init(top.color().x(), grad.dR_dx, grad.dR_dy, r, r_step);
            init(top.color().y(), grad.dG_dx, grad.dG_dy, g, g_step);
            init(top.color().z(), grad.dB_dx, grad.dB_dy, b, b_step);
            init(top.alpha(), grad.dA_dx, grad.dA_dy, a, a_step);
            init(top.normal().x(), grad.dNx_dx, grad.dNx_dy, nx, nx_step);
            init(top.normal().y(), grad.dNy_dx, grad.dNy_dy, ny, ny_step);
            init(top.normal().z(), grad.dNz_dx, grad.dNz_dy, nz, nz_step);
        }

        inline void Step()
        {
            x += xStep;

            invW += invW_step;

            u += u_step;
            v += v_step;

            fxu += fxu_step;
            fxv += fxv_step;

            r += r_step;
            g += g_step;
            b += b_step;
            a += a_step;

            nx += nx_step;
            ny += ny_step;
            nz += nz_step;
        }
    };

    template<class T>
    inline void DrawSpan(RenderTarget<T>& target, const DrawState<T>& st, const Gradients<T>& grad, int y, const Edge<T>& left, const Edge<T>& right)
    {
        int xStart = (int)std::ceil(left.x - (T)0.5);
        int xEnd = (int)std::ceil(right.x - (T)0.5);
        if (xStart >= xEnd) return;

        T xPreStep = ((T)xStart + (T)0.5) - left.x;

        Fragment<T> f;
        f.y = y;
        f.invW = left.invW + xPreStep * grad.dInvW_dx;
        f.u = left.u + xPreStep * grad.dU_dx;
        f.v = left.v + xPreStep * grad.dV_dx;
        f.fxu = left.fxu + xPreStep * grad.dFxu_dx;
        f.fxv = left.fxv + xPreStep * grad.dFxv_dx;
        f.r = left.r + xPreStep * grad.dR_dx;
        f.g = left.g + xPreStep * grad.dG_dx;
        f.b = left.b + xPreStep * grad.dB_dx;
        f.a = left.a + xPreStep * grad.dA_dx;
        f.nx = left.nx + xPreStep * grad.dNx_dx;
        f.ny = left.ny + xPreStep * grad.dNy_dx;
        f.nz = left.nz + xPreStep * grad.dNz_dx;

        f.dudx = f.dvdx = f.dudy = f.dvdy = 0;

        const bool needDerivs = (st.flags & RASTER_TEXTURE) != 0;

        for (int x = xStart; x < xEnd; x++)
        {
            f.x = x;

            // Perspektivisch korrektes UV: die eine Division pro Pixel.
            const T w = (T)1 / f.invW;
            Fragment<T> shaded = f;
            shaded.u = f.u * w;
            shaded.v = f.v * w;
            shaded.fxu = f.fxu * w;
            shaded.fxv = f.fxv * w;

            // FIX: Ableitungen pro Pixel (aendern sich entlang der Zeile),
            // mit korrigierter Quotientenregel.
            if (needDerivs)
            {
                shaded.dudx = PerspectiveDerivative(f.u, w, grad.dU_dx, grad.dInvW_dx);
                shaded.dvdx = PerspectiveDerivative(f.v, w, grad.dV_dx, grad.dInvW_dx);
                shaded.dudy = PerspectiveDerivative(f.u, w, grad.dU_dy, grad.dInvW_dy);
                shaded.dvdy = PerspectiveDerivative(f.v, w, grad.dV_dy, grad.dInvW_dy);
            }

            ShadePixel(target, st, shaded);

            f.invW += grad.dInvW_dx;
            f.u += grad.dU_dx; f.v += grad.dV_dx;
            f.fxu += grad.dFxu_dx; f.fxv += grad.dFxv_dx;
            f.r += grad.dR_dx; f.g += grad.dG_dx; f.b += grad.dB_dx; f.a += grad.dA_dx;
            f.nx += grad.dNx_dx; f.ny += grad.dNy_dx; f.nz += grad.dNz_dx;
        }
    }

    // Haupteinstieg: Dreieck aus bereits projizierten SVertex rastern.
    template<class T, class SVertexT>
    inline void DrawTriangleFast(RenderTarget<T>& target, DrawState<T>& st, SVertexT v0, SVertexT v1, SVertexT v2)
    {
        SelectDrawFunctions(st);

        if (v0.y() > v1.y()) std::swap(v0, v1);
        if (v1.y() > v2.y()) std::swap(v1, v2);
        if (v0.y() > v1.y()) std::swap(v0, v1);

        if (std::abs(v0.y() - v2.y()) < (T)1e-6) return;
        Gradients<T> grad(v0, v1, v2);

        // Handedness bestimmen: liegt v1 links oder rechts der langen Kante v0->v2?
        T area = (v2.x() - v0.x()) * (v1.y() - v0.y()) - (v2.y() - v0.y()) * (v1.x() - v0.x());
        bool middleIsLeft = area >= (T)0;

        Edge<T> longEdge(v0, v2, grad);

        if (v0.y() < v1.y())
        {
            Edge<T> shortEdge(v0, v1, grad);
            for (int y = shortEdge.yStart; y < shortEdge.yEnd; y++)
            {
                if (middleIsLeft) DrawSpan(target, st, grad, y, shortEdge, longEdge);
                else              DrawSpan(target, st, grad, y, longEdge, shortEdge);
                shortEdge.Step();
                longEdge.Step();
            }
        }
        if (v1.y() < v2.y())
        {
            Edge<T> shortEdge(v1, v2, grad);

            for (int y = shortEdge.yStart; y < shortEdge.yEnd; y++)
            {
                if (middleIsLeft) DrawSpan(target, st, grad, y, shortEdge, longEdge);
                else              DrawSpan(target, st, grad, y, longEdge, shortEdge);
                shortEdge.Step();
                longEdge.Step();
            }
        }
    }

} // namespace ng::renderer::rasterizer